package bean;

import java.io.Serializable;
import java.time.LocalDate;

//m_employeeテーブルのBean(従業員情報)
public class Employee implements Serializable {

	private String code; //従業員コード
	private String lastName; //苗字
	private String firstName; //名前
	private String lastKanaName; //かな苗字
	private String firstKanaName; //かな名前
	private int gender; //性別(0=男,1=女)
	private LocalDate birthDay; //生年月日
	private String sectionCode; //部署コード
	private LocalDate hireDate; //入社日
	private String password; //パスワード

	public String getCode() {
		return code;
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastKanaName() {
		return lastKanaName;
	}

	public String getFirstKanaName() {
		return firstKanaName;
	}

	public int getGender() {
		return gender;
	}

	public LocalDate getBirthDay() {
		return birthDay;
	}

	public String getSectionCode() {
		return sectionCode;
	}

	public LocalDate getHireDate() {
		return hireDate;
	}

	public String getpassword() {
		return password;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastKanaName(String lastKanaName) {
		this.lastKanaName = lastKanaName;
	}

	public void setFirstKanaName(String firstKanaName) {
		this.firstKanaName = firstKanaName;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public void setBirthDay(LocalDate birthDay) {
		this.birthDay = birthDay;
	}

	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}

	public void setpassword(String password) {
		this.password = password;
	}

}
