package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tool.Action;

//出退勤時刻情報を画面に表示させるアクション
public class AttendanceViewTimecardAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("employeeCode") != null) {
			//従業員コードの取得
			String employeeCode = (String)session.getAttribute("employeeCode");

			//DAOクラスの準備
			WorkTimeDAO dao = new WorkTimeDAO();

			try {

			} catch(Exception e) {
				e.printStackTrace();
			}

			return "attendance_timecard.jsp";
		} else {
			return "../action/attendance_login.jsp";
		}

	}

}
