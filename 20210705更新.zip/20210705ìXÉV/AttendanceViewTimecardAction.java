package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.WorkTimeDAO;
import tool.Action;

//出退勤時刻情報を画面に表示させるアクション
public class AttendanceViewTimecardAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("employeeCode") != null) {
			//従業員コードの取得
			String employeeCode = (String)session.getAttribute("employeeCode");

			//ボタン入力可否判定用
			String workStart = null; //出勤
			String workFinish = null; //退勤
			String breakStart = null; //休憩開始
			String breakFinish = null; //休憩終了

			//DAOクラスの準備
			WorkTimeDAO dao = new WorkTimeDAO();

			try {
				//出勤情報の確認
				String workStartChk = dao.selectStartTime(employeeCode);
				System.out.println(workStartChk);

				//出勤情報により分岐 ※分岐うまく行ってない
				if(workStartChk == null) {
					//休憩情報の確認
					String workFinishChk = dao.selectBreakTime(employeeCode);

					//休憩情報による分岐
					if(workFinishChk == null) {
						breakFinish = workFinishChk;
					} else if(workFinishChk.equals("disable")) {
						workFinish = workFinishChk;
						breakStart = workFinishChk;
					}

				} else if(workStartChk.equals("disable")) {
					workStart = workStartChk;
				}

			} catch(Exception e) {
				e.printStackTrace();
			}

			//ボタン入力可否情報を設定
			session.setAttribute("startWork", workStart);
			session.setAttribute("finishWork", workFinish);
			session.setAttribute("startBreak", breakStart);
			session.setAttribute("finishBreak", breakFinish);

			return "attendance_timecard.jsp";
		} else {
			return "../action/attendance_login.jsp";
		}

	}

}
