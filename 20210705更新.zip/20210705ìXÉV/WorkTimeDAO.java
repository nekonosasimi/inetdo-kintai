package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

//勤怠管理のDAOクラス
public class WorkTimeDAO extends DAO {

	//出勤ボタンを押せる状態かのチェック
	public String selectStartTime(String code) throws Exception {
		String workStart = null; //出勤状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザの退勤していない情報の有無を検索)
		String sql = "select * from work_time where employee_code = ? and finish_time = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setTime(2, null);
		ResultSet rs = st.executeQuery();

		//退勤していない情報があるかの確認
		if(!rs.next()) {
			//SQL文の実行(指定ユーザの最終退勤日を検索)
			sql = "select work_date from work_time where employee_code = ?";
			st = con.prepareStatement(sql);
			st.setString(1, code);
			rs = st.executeQuery();

			//指定ユーザの退勤情報があるかの確認
			if(rs.next() && rs.getDate(1) != null) {
				//最終退勤日の取得
				LocalDate finishDate = rs.getDate(1).toLocalDate();

				//最終退勤日が本日中であるかの確認
				if(finishDate == LocalDate.now()) {
					workStart = "allBreak";
				} else {
					workStart = "disable";
				}

			} else {
				workStart = "disable";
			}

		}

		return workStart;
	}

	//退勤ボタンを押せる状態かのチェック
	public String selectBreakTime(String code) throws Exception {
		String breakFinish = null; //退勤状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザの休憩終了していない情報の有無を検索)
		String sql = "select * from work_break where employee_code = ? and break_time = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setTime(2, null);
		ResultSet rs = st.executeQuery();

		//休憩終了していない情報があるかの確認
		if(!rs.next()) {
			breakFinish = "disable";
		}

		return breakFinish;
	}

}
