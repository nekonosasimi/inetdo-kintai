package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.List;

import bean.WorkTime;

//勤怠管理のDAOクラス
public class WorkTimeDAO extends DAO {

	//出勤ボタンが押せるかのチェック(出勤していない場合にtrueを返す)
	public boolean selectStartTime(String code) throws Exception {
		boolean workStart = true; //出勤状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザの本日の出勤情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(LocalDate.now()));
		ResultSet rs = st.executeQuery();

		//本日出勤済みであるかの確認
		if(rs.next()) {
			workStart = false;
		}

		//クローズ処理
		st.close();
		con.close();

		return workStart;
	}

	//退勤ボタンが押せるかのチェック(勤務中であり退勤していない場合にtrueを返す)
	public boolean selectFinishTime(String code) throws Exception {
		boolean workFinish = true; //退勤状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザの退勤していない情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and finish_time is null";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		ResultSet rs = st.executeQuery();

		//退勤していない情報があるかの確認
		if(!rs.next()) {
			workFinish = false;
		}

		//クローズ処理
		st.close();
		con.close();

		return workFinish;
	}

	//休憩開始、終了ボタンどちらが押せるかのチェック(勤務中であり退勤しておらず、休憩中でない場合にtrueを返す)
	public boolean selectStartBreak(String code) throws Exception {
		boolean breakStart = true; //休憩状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザの出勤情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and finish_time is null";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		ResultSet rs = st.executeQuery();

		//本日まだ退勤していないかの確認
		if(rs.next()) {
			//SQL文の実行(指定ユーザの休憩中の情報があるか検索)
			sql = "select * from break_time where employee_code = ? and break_finish_time is null";
			st = con.prepareStatement(sql);
			st.setString(1, code);
			rs = st.executeQuery();

			//休憩中であるかで分岐
			if(rs.next()) {
				breakStart = false;
			}

		}

		//クローズ処理
		st.close();
		con.close();

		return breakStart;
	}

	/*

	//本日の休憩終了チェック(休憩終了している場合に「disable」を返す)
	public boolean selectFinishBreak(String code) throws Exception {
		boolean breakFinish = true; //休憩状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザの本日の出勤情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(LocalDate.now()));
		ResultSet rs = st.executeQuery();

		//本日まだ退勤していないかの確認
		if(rs.next() && rs.getTime(4) == null) {
			//SQL文の実行(指定ユーザの休憩中の情報があるか検索)
			sql = "select * from break_time where employee_code = ? and break_finish_time = ?";
			st = con.prepareStatement(sql);
			st.setString(1, code);
			st.setTime(2, null);
			rs = st.executeQuery();

			//休憩中であるかで分岐
			if(!rs.next()) {
				breakFinish = false;
			}

		}

		//クローズ処理
		st.close();
		con.close();

		return breakFinish;
	}

	*/

	//指定した月の勤務情報を取得
	public List<WorkTime> selectWorkTimeThisMonthList(String code, String month) throws Exception {
		List<WorkTime> list = new LinkedList<WorkTime>(); //勤務情報リスト格納用

		//コネクションの取得
		Connection con = getConnection();

		 //検索範囲の設定
		LocalDate startDay = LocalDate.parse(month + "-01"); //最小の日
		LocalDate finishDay = null; //最大の日

		//検索範囲(最大の日)の取得
		int dayLength = startDay.lengthOfMonth();

		//日付の桁数による分岐
		if(dayLength < 10) {
			finishDay = LocalDate.parse(month + "-0" + dayLength);
		} else {
			finishDay = LocalDate.parse(month + "-" + dayLength);
		}

		//SQL文の実行(指定した月の指定したユーザの勤務情報を検索)
		String sql = "select * from work_time where employee_code = ? and work_date between ? and ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(startDay));
		st.setDate(3, Date.valueOf(finishDay));
		ResultSet rs = st.executeQuery();

		//検索結果をリストに格納
		while(rs.next()) {
			WorkTime item = new WorkTime();
			item.setCode(rs.getString(1));
			item.setWorkDate(rs.getDate(2).toLocalDate());

			if(rs.getTime(3) != null) {
				item.setStartTime(rs.getTime(3).toLocalTime());
			}

			if(rs.getTime(4) != null) {
				item.setFinishTime(rs.getTime(4).toLocalTime());
			}

			/*

			if(rs.getTime(5) != null) {
				item.setBreakStartTime(rs.getTime(5).toLocalTime());
			}

			if(rs.getTime(6) != null) {
				item.setBreakFinishTime(rs.getTime(6).toLocalTime());
			}

			*/

			if(rs.getTime(6) != null) {
				item.setBreakTime(Duration.between(LocalTime.of(0, 0, 0), rs.getTime(6).toLocalTime()));
			}

			if(rs.getTime(7) != null) {
				item.setWorkingHours(Duration.between(LocalTime.of(0, 0, 0), rs.getTime(7).toLocalTime()));
			}

			list.add(item);
		}

		return list;
	}

}
