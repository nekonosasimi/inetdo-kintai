package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDAO;
import tool.Action;

//管理者情報の登録を行うアクション
public class RegistAdminUserAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("userId") != null) {
			//入力情報の取得
			String id = request.getParameter("userId");
			String password = request.getParameter("password");

			//DAOクラス使用準備
			UserDAO dao = new UserDAO();

			boolean insertChk = false; //データ登録確認用

			//管理者情報の登録
			try {
				insertChk = dao.insertUser(id, password);
			} catch(Exception e) {
				e.printStackTrace();
			}

			//登録が成功したかの確認
			if(insertChk) {
				return "completion.jsp";
			} else {
				return "regist_adminuser_error.jsp";
			}

		} else {
			return "../action/user_login.jsp";
		}

	}

}
