package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.WorkTimeDAO;
import tool.Action;

//出退勤時刻情報を画面に表示させるアクション
public class AttendanceViewTimecardAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("employeeCode") != null) {
			//従業員コードの取得
			String employeeCode = (String)session.getAttribute("employeeCode");

			//DAOクラスの準備
			WorkTimeDAO dao = new WorkTimeDAO();

			boolean startChk = false; //出勤ボタン押下可否確認用
			boolean finishChk = false; //退勤ボタン押下可否確認用
			boolean startBreakChk = false; //休憩開始ボタン押下可否確認用
			boolean finishBreakChk = false; //休憩終了ボタン押下可否確認用

			try {
				finishChk = dao.selectFinishTime(employeeCode); //退勤前であるかの確認

				//退勤ボタンが押せるかの分岐
				if(finishChk) {
					startBreakChk = dao.selectStartBreak(employeeCode); //休憩中でないかの確認

					//休憩開始ボタンが押せるかの分岐(休憩中の場合は退勤もを押せないようにする)
					if (startBreakChk) {
						finishBreakChk = false;
					} else {
						finishChk = false;
						finishBreakChk = true;
					}

				} else {
					startChk = dao.selectStartTime(employeeCode); //出勤前であるかの確認
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			//ボタン表示の設定
			session.setAttribute("startWork", Boolean.toString(Boolean.valueOf(startChk)));
			session.setAttribute("finishWork", Boolean.toString(Boolean.valueOf(finishChk)));
			session.setAttribute("startBreak", Boolean.toString(Boolean.valueOf(startBreakChk)));
			session.setAttribute("finishBreak", Boolean.toString(Boolean.valueOf(finishBreakChk)));

			return "attendance_timecard.jsp";
		} else {
			return "../action/attendance_login.jsp";
		}

	}

}
