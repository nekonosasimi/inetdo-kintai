package action;

import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ViewListDisplay;
import dao.ViewListDAO;
import tool.Action;

//すべての従業員情報を取得するアクション
public class DisplayEmployeeListAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		List<ViewListDisplay> vldList = new LinkedList<ViewListDisplay>(); //従業員情報格納用リスト

		//ログインしているかのチェック
		if(session.getAttribute("userId") != null) {
			//従業員情報表示のDAOクラス使用準備
			ViewListDAO dao = new ViewListDAO();

			//部署データの取得
			try {
				vldList = dao.showAllList();
			} catch(Exception e) {
				e.printStackTrace();
			}

			session.setAttribute("vldList", vldList);
			return "show_all_employee.jsp";
		} else {
			return "../action/user_login.jsp";
		}

	}

}
