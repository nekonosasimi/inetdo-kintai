package action;

import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Section;
import dao.EmployeeDAO;
import tool.Action;

//部署データを取得するアクション(登録画面の選択肢で使用)
public class GetSectionEmployeeAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		List<Section> sections = new LinkedList<Section>(); //部署情報格納用リスト

		//ログインしているかのチェック
		if(session.getAttribute("userId") != null) {
			//m_employeeテーブルのDAOクラス使用準備
			EmployeeDAO dao = new EmployeeDAO();

			//部署データの取得
			try {
				sections = dao.getSection();
			} catch(Exception e) {
				e.printStackTrace();
			}

			//セッションに部署データをセット
			session.setAttribute("sections", sections);
			return "regist_employee.jsp";
		} else {
			return "../action/user_login.jsp";
		}

	}

}
