drop table work_time if exists;

create table work_time (
	employee_code varchar(100) not null,
	work_date date not null,
	start_time time,
	finish_time time,
	break_time_id varchar(100),
	break_time time,
	working_hours time
);

insert into work_time values();

select * from work_time;