drop table break_time if exists;

create table break_time (
	break_id varchar(100) primary key,
	employee_code varchar(100) not null,
	break_start_time time,
	break_finish_time time,
	break_time time
);

insert into break_time values();

select * from break_time;