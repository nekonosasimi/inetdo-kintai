package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.WorkTimeDAO;
import tool.Action;

//出退勤時刻情報を画面に表示させるアクション
public class AttendanceViewTimecardAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("employeeCode") != null) {
			//従業員コードの取得
			String employeeCode = (String)session.getAttribute("employeeCode");

			//DAOクラスの準備
			WorkTimeDAO dao = new WorkTimeDAO();

			String startChk = null; //出勤情報確認用
			String finishChk = null; //退勤情報確認用
			String startBreakChk = null; //休憩開始情報確認用
			String finishBreakChk = null; //休憩終了情報確認用

			try {
				startChk = dao.selectStartTime(employeeCode); //出勤情報の確認

				//出勤情報があるかの確認
				if(startChk != null) {
					finishChk = dao.selectFinishTime(employeeCode); //退勤情報の確認

					//退勤情報がないかの確認
					if (finishChk == null) {
						startBreakChk = dao.selectStartBreak(employeeCode); //休憩開始情報の確認

						//休憩開始情報があるかの確認
						if (startBreakChk != null) {
							finishBreakChk = dao.selectFinishBreak(employeeCode); //休憩終了情報の確認
						}

					}

				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			//ボタン表示の設定
			session.setAttribute("startWork", startChk);
			session.setAttribute("finishWork", finishChk);
			session.setAttribute("startBreak", startBreakChk);
			session.setAttribute("finishBreak", finishBreakChk);

			return "attendance_timecard.jsp";
		} else {
			return "../action/attendance_login.jsp";
		}

	}

}
