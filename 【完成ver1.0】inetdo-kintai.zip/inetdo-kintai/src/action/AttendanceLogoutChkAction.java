package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tool.Action;

//従業員ログアウト時のアクション
public class AttendanceLogoutChkAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログイン情報の有無確認
		if(session.getAttribute("employeeCode") != null || session.getAttribute("employeePassword") != null) {
			//ログイン情報の削除
			session.removeAttribute("employeeCode");
			session.removeAttribute("employeePassword");
			return "attendance_logout.jsp";
		} else {
			return "attendance_logout_error.jsp";
		}

	}

}
