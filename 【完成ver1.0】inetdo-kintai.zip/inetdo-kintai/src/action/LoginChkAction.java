package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDAO;
import tool.Action;

//管理者ログイン時のアクション
public class LoginChkAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログイン情報の取得
		String id = request.getParameter("userId");
		String password = request.getParameter("userPassword");

		//m_userテーブルのDAOクラス使用準備
		UserDAO dao = new UserDAO();

		boolean loginChk = false; //ログイン情報認証判定用

		//ログイン認証判定
		try {
			loginChk = dao.loginUser(id, password);
		} catch(Exception e) {
			e.printStackTrace();
		}

		//ログイン認証正否による分岐
		if(loginChk) {
			//セッション属性の登録
			session.setAttribute("userId", id);
			session.setAttribute("userPassword", password);
			return "user_menu.jsp";
		} else {
			return "user_login_error.jsp";
		}

	}

}
