package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.EmployeeDAO;
import tool.Action;

//従業員ログイン時のアクション
public class AttendanceLoginChkAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログイン情報の取得
		String code = request.getParameter("employeeCode");
		String password = request.getParameter("password");

		//DAOクラス使用準備
		EmployeeDAO dao = new EmployeeDAO();

		boolean loginChk = false; //ログイン情報認証判定用

		//ログイン認証判定
		try {
			loginChk = dao.loginEmployee(code, password);
		} catch(Exception e) {
			e.printStackTrace();
		}

		//ログイン認証正否による分岐
		if(loginChk) {
			//ログイン情報をセッションに登録
			session.setAttribute("employeeCode", code);
			session.setAttribute("employeePassword", password);
			return "attendance_menu.jsp";
		} else {
			return "attendance_login_error.jsp";
		}

	}

}
