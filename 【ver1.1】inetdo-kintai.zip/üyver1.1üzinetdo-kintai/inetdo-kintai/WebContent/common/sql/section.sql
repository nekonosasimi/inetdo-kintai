drop table section if exists;

create table section (
	section_code varchar(100) not null primary key,
	section_name varchar(100) not null
);

insert into section values('a1', 'maguro');

select * from section;