package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

public class AttendanceEmployeeDAO extends DAO {

	//出勤情報を登録
	public boolean setStartTime(String code) throws Exception {
		boolean flag = false; //登録成否判定用

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//現在の日付と時間を取得
		LocalDate nowDate = LocalDate.now();
		LocalTime nowTime = LocalTime.now();

		//SQL文の実行(指定ユーザの本日の出勤情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(nowDate));
		ResultSet rs = st.executeQuery();

		//出勤情報がすでにないかで分岐
		if(!rs.next()) {
			//SQL文の実行(指定ユーザの本日の出勤情報を登録)
			sql = "insert into work_time values(?, ?, ?, null, null, null, null)";
			st = con.prepareStatement(sql);
			st.setString(1, code);
			st.setDate(2, Date.valueOf(nowDate));
			st.setTime(3, Time.valueOf(nowTime));
			int line = st.executeUpdate();

			//登録の成否で分岐
			if(line > 0) {
				con.commit(); //コミット
				flag = true;
			} else {
				con.rollback(); //ロールバック
			}

		}

		//オートコミットの設定を戻す
		con.setAutoCommit(true);

		//クローズ処理
		st.close();
		con.close();

		return flag;
	}

	//退勤情報を更新
	public boolean setFinishTime(String code) throws Exception {
		boolean flag = false; //更新成否判定用

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//現在の日付と時間を取得
		LocalTime nowTime = LocalTime.now();

		//SQL文の実行(指定ユーザの勤務中の情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and finish_time is null";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		ResultSet rs = st.executeQuery();

		//勤務中かどうかで分岐
		if(rs.next()) {
			String updateDate = rs.getDate(2).toString(); //勤務中データの日付を取得
			Duration breakTime = null; //休憩時間格納用

			//休憩時間の取得
			if(rs.getTime(6) == null) {
				breakTime = Duration.between(LocalTime.of(0, 0, 0), LocalTime.of(0, 0, 0));
			} else {
				breakTime = Duration.between(LocalTime.of(0, 0, 0), rs.getTime(6).toLocalTime());
			}

			//勤務時間の取得
			Duration workTime = Duration.between(rs.getTime(3).toLocalTime(), nowTime).minus(breakTime);

			//SQL文の実行(指定ユーザの休憩中の情報があるか検索)
			sql = "select * from break_time where employee_code = ? and break_finish_time is null";
			st = con.prepareStatement(sql);
			st.setString(1, code);
			rs = st.executeQuery();

			//休憩終了していない情報がないかで分岐
			if(!rs.next()) {
				//SQL文の実行(退勤情報の更新)
				sql = "update work_time set finish_time = ?, working_hours = ? where employee_code = ? "
						+ "and work_date = ?";
				st = con.prepareStatement(sql);
				st.setTime(1, Time.valueOf(nowTime));
				st.setTime(2, Time.valueOf(LocalTime.MIDNIGHT.plus(workTime)));
				st.setString(3, code);
				st.setDate(4, Date.valueOf(updateDate));
				int line = st.executeUpdate();

				//勤怠更新の成否で分岐
				if(line > 0) {
					con.commit(); //コミット
					flag = true;
				} else {
					con.rollback(); //ロールバック
				}

			}

		}

		//オートコミットの設定を戻す
		con.setAutoCommit(true);

		//クローズ処理
		st.close();
		con.close();

		return flag;
	}

	//休憩開始情報を登録
	public boolean setStartBreakTime(String code) throws Exception {
		boolean flag = false; //更新成否判定用

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//現在の時間を取得
		LocalTime nowTime = LocalTime.now();

		//SQL文の実行(指定ユーザの勤務中の情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and finish_time is null";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		ResultSet rs = st.executeQuery();

		//勤務中かどうかで分岐
		if(rs.next()) {
			String updateDate = rs.getDate(2).toString(); //勤務中データの日付を取得
			String breakIds = rs.getString(5); //休憩情報の取得

			//SQL文の実行(指定ユーザの休憩中の情報があるか検索)
			sql = "select * from break_time where employee_code = ? and break_finish_time is null";
			st = con.prepareStatement(sql);
			st.setString(1, code);
			rs = st.executeQuery();

			//休憩終了していない情報がないかで分岐
			if(!rs.next()) {
				//SQL文の実行(休憩IDの最大値を取得)
				sql = "select max(break_id) from break_time";
				st = con.prepareStatement(sql);
				rs = st.executeQuery();

				String headId; //コードの英字部分
				int footId; //コードの数字部分
				String id; //登録する従業員コード

				//登録する情報の従業員コード作成
				if(rs.next() && rs.getString(1) != null) {
					headId = rs.getString(1).substring(0, 2);
					footId = Integer.parseInt(rs.getString(1).substring(2)) + 1;
					id = headId + String.format("%05d", footId);
				} else {
					id = "RT" + String.format("%05d", 1);
				}

				//SQL文の実行(指定ユーザの休憩開始時刻を登録)
				sql = "insert into break_time values(?, ?, ?, null, null)";
				st = con.prepareStatement(sql);
				st.setString(1, id);
				st.setString(2, code);
				st.setTime(3, Time.valueOf(nowTime));
				int line = st.executeUpdate();

				//休憩情報更新の成否で分岐
				if(line > 0) {
					//更新する休憩情報の設定
					if(breakIds == null) {
						breakIds = id;
					} else {
						breakIds = breakIds + " " + id;
					}

					//SQL文の実行(休憩情報の追加)
					sql = "update work_time set break_time_id = ? where employee_code = ? and work_date = ?";
					st = con.prepareStatement(sql);
					st.setString(1, breakIds);
					st.setString(2, code);
					st.setDate(3, Date.valueOf(updateDate));
					line = st.executeUpdate();

					//勤怠更新の成否で分岐
					if(line > 0) {
						con.commit(); //コミット
						flag = true;
					} else {
						con.rollback(); //ロールバック
					}

				} else {
					con.rollback(); //ロールバック
				}

			}

		}

		//オートコミットの設定を戻す
		con.setAutoCommit(true);

		//クローズ処理
		st.close();
		con.close();

		return flag;
	}

	//休憩終了情報を更新
	public boolean setFinishBreakTime(String code) throws Exception {
		boolean flag = false; //更新成否判定用

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//現在の時間を取得
		LocalTime nowTime = LocalTime.now();

		//SQL文の実行(指定ユーザの勤務中の情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and finish_time is null";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		ResultSet rs = st.executeQuery();

		//勤務中かどうかで分岐
		if(rs.next()) {
			String updateDate = rs.getDate(2).toString(); //勤務中データの日付を取得
			Duration updateBreakTime = null; //今までの休憩時間格納用

			//今までの休憩時間の取得
			if(rs.getTime(6) == null) {
				updateBreakTime = Duration.between(LocalTime.of(0, 0, 0), LocalTime.of(0, 0, 0));
			} else {
				updateBreakTime = Duration.between(LocalTime.of(0, 0, 0), rs.getTime(6).toLocalTime());
			}

			//SQL文の実行(指定ユーザの休憩中の情報があるか検索)
			sql = "select * from break_time where employee_code = ? and break_finish_time is null";
			st = con.prepareStatement(sql);
			st.setString(1, code);
			rs = st.executeQuery();

			//休憩終了していない情報があるかで分岐
			if(rs.next()) {
				String breakId = rs.getString(1); //休憩情報IDの取得
				LocalTime breakStart = rs.getTime(3).toLocalTime(); //休憩開始時刻の取得
				Duration breakTime = Duration.between(breakStart, nowTime); //追加する休憩時間の取得

				//SQL文の実行(指定ユーザの休憩時間を更新)
				sql = "update break_time set break_finish_time = ?, break_time = ? where break_id = ?";
				st = con.prepareStatement(sql);
				st.setTime(1, Time.valueOf(nowTime));
				st.setTime(2, Time.valueOf(LocalTime.MIDNIGHT.plus(breakTime)));
				st.setString(3, breakId);
				int line = st.executeUpdate();

				//休憩情報更新の成否で分岐
				if(line > 0) {
					//総合の休憩時間を取得
					updateBreakTime = updateBreakTime.plus(breakTime);

					//SQL文の実行(休憩時間の追加)
					sql = "update work_time set break_time = ? where employee_code = ? and work_date = ?";
					st = con.prepareStatement(sql);
					st.setTime(1, Time.valueOf(LocalTime.MIDNIGHT.plus(updateBreakTime)));
					st.setString(2, code);
					st.setDate(3, Date.valueOf(updateDate));
					line = st.executeUpdate();

					//勤怠情報更新の成否で分岐
					if(line > 0) {
						con.commit(); //コミット
						flag = true;
					} else {
						con.rollback(); //ロールバック
					}

				} else {
					con.rollback(); //ロールバック
				}

			}

		}

		//オートコミットの設定を戻す
		con.setAutoCommit(true);

		//クローズ処理
		st.close();
		con.close();

		return flag;
	}

}
