package dao;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

//各DAOクラスのスーパークラス
public class DAO {
	static DataSource ds; //データソース格納用

	//データベースへの接続を取得
	public Connection getConnection() throws Exception {

		//データベースの接続有無による分岐
		if(ds == null) {
			//データソースの取得
			InitialContext ic = new InitialContext();
			ds = (DataSource)ic.lookup("java:/comp/env/jdbc/inetdo");
		}

		return ds.getConnection();
	}

}
