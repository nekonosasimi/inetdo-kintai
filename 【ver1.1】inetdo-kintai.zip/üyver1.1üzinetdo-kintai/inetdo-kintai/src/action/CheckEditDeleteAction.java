package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tool.Action;

//従業員情報の編集、削除の識別を行うアクション
public class CheckEditDeleteAction extends Action {

	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("userId") != null) {
			//選択した処理を取得
			String submit = request.getParameter("submit");
			String className = null;

			//選択した処理で分岐
			switch(submit) {
				case "従業員を編集する":
					className = "action.EditCheckEmployeeAction";
					break;
				case "従業員を削除する":
					className = "action.DeleteEmployeeAction";
					break;
			}

			//処理が正しく受け取れたか確認
			if(className != null) {
				//選択している従業員情報の従業員コードをセッションに登録
				session.setAttribute("employeeCode", request.getParameter("employeeCode"));

				//処理に対応するアクションに移行
				Action action = (Action)Class.forName(className).newInstance();
				return action.execute(request, response);
			} else {
				return "show_all_employee.jsp";
			}

		} else {
			return "../action/user_login.jsp";
		}

	}

}
