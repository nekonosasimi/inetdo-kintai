package action;

import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Employee;
import bean.Section;
import dao.EmployeeDAO;
import tool.Action;

//従業員情報の編集準備を行うアクション(編集画面への遷移)
public class EditCheckEmployeeAction extends Action {

	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("userId") != null) {
			//選択した従業員情報の従業員コードを取得
			String employeeCode = (String)session.getAttribute("employeeCode");

			//従業員コードが取得できたか確認
			if(employeeCode != null) {
				//m_employeeテーブルのDAOクラス使用準備
				EmployeeDAO dao = new EmployeeDAO();
				Employee employee = null; //従業員データ格納用変数
				List<Section> sections = new LinkedList<Section>(); //部署情報格納用リスト

				//取得した従業員コードの従業員情報を取得
				//すべての部署情報の取得
				try {
					employee = dao.selectEmployee(employeeCode);
					sections = dao.getSection();
				} catch(Exception e) {
					e.printStackTrace();
				}

				//取得した情報をセッションに登録
				session.setAttribute("employee", employee);
				session.setAttribute("sections", sections);

				//取得した従業員コードの従業員情報が存在するか確認
				if(employee != null) {
					return "edit_employee.jsp";
				} else {
					return "user_menu.jsp";
				}

			} else {
				return "show_all_employee.jsp";
			}

		} else {
			return "../action/user_login.jsp";
		}

	}

}
