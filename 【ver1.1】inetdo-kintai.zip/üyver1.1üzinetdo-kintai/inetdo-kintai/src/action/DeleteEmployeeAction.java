package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.EmployeeDAO;
import tool.Action;

//従業員情報の削除を行うアクション
public class DeleteEmployeeAction extends Action {

	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("userId") != null) {
			String code = (String)session.getAttribute("employeeCode"); //削除する従業員情報の従業員コード
			boolean deleteChk = false; //削除正否確認用変数

			//DAOクラス使用準備
			EmployeeDAO dao = new EmployeeDAO();

			//従業員データの削除
			try {
				deleteChk = dao.deleteEmployee(code);
			} catch(Exception e) {
				e.printStackTrace();
			}

			//削除正否による分岐
			if(deleteChk) {
				return "delete_completion.jsp";
			} else {
				return "delete_employee_error.jsp";
			}

		} else {
			return "../action/user_login.jsp";
		}
	}

}
