package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.List;

import bean.WorkTime;

//勤怠管理のDAOクラス
public class WorkTimeDAO extends DAO {

	//本日の出勤チェック(出勤している場合に「disable」を返す)
	public String selectStartTime(String code) throws Exception {
		String workStart = null; //出勤状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザの本日の出勤情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(LocalDate.now()));
		ResultSet rs = st.executeQuery();

		//本日の出勤状況で分岐
		if(rs.next()) {
			workStart = "disable";
		}

		//クローズ処理
		st.close();
		con.close();

		return workStart;
	}

	//本日の退勤チェック(退勤している場合に「disable」を返す)
	public String selectFinishTime(String code) throws Exception {
		String workFinish = null; //退勤状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザが本日退勤していないか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(LocalDate.now()));
		ResultSet rs = st.executeQuery();

		//本日の退勤状況で分岐
		if(rs.next() && rs.getTime(4) != null) {
			workFinish = "disable";
		}

		//クローズ処理
		st.close();
		con.close();

		return workFinish;
	}

	//本日の休憩開始チェック(休憩開始している場合に「disable」を返す)
	public String selectStartBreak(String code) throws Exception {
		String breakStart = null; //休憩状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザが本日休憩を開始していないか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(LocalDate.now()));
		ResultSet rs = st.executeQuery();

		//本日の休憩開始状況で分岐
		if(rs.next() && rs.getTime(5) != null) {
			breakStart = "disable";
		}

		//クローズ処理
		st.close();
		con.close();

		return breakStart;
	}

	//本日の休憩終了チェック(休憩終了している場合に「disable」を返す)
	public String selectFinishBreak(String code) throws Exception {
		String breakFinish = null; //休憩状態確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定ユーザが本日休憩を終了していないか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(LocalDate.now()));
		ResultSet rs = st.executeQuery();

		//本日の休憩終了状況で分岐
		if(rs.next() && rs.getTime(6) != null) {
			breakFinish = "disable";
		}

		//クローズ処理
		st.close();
		con.close();

		return breakFinish;
	}

	//指定した月の勤務情報を取得
	public List<WorkTime> selectWorkTimeThisMonthList(String code, String month) throws Exception {
		List<WorkTime> list = new LinkedList<WorkTime>(); //勤務情報リスト格納用

		//コネクションの取得
		Connection con = getConnection();

		 //検索範囲の設定
		LocalDate startDay = LocalDate.parse(month + "-01"); //最小の日
		LocalDate finishDay = null; //最大の日

		//検索範囲(最大の日)の取得
		int dayLength = startDay.lengthOfMonth();

		//日付の桁数による分岐
		if(dayLength < 10) {
			finishDay = LocalDate.parse(month + "-0" + dayLength);
		} else {
			finishDay = LocalDate.parse(month + "-" + dayLength);
		}

		//SQL文の実行(指定した月の指定したユーザの勤務情報を検索)
		String sql = "select * from work_time where employee_code = ? and work_date between ? and ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(startDay));
		st.setDate(3, Date.valueOf(finishDay));
		ResultSet rs = st.executeQuery();

		//検索結果をリストに格納
		while(rs.next()) {
			WorkTime item = new WorkTime();
			item.setCode(rs.getString(1));
			item.setWorkDate(rs.getDate(2).toLocalDate());

			if(rs.getTime(3) != null) {
				item.setStartTime(rs.getTime(3).toLocalTime());
			}

			if(rs.getTime(4) != null) {
				item.setFinishTime(rs.getTime(4).toLocalTime());
			}

			if(rs.getTime(5) != null) {
				item.setBreakStartTime(rs.getTime(5).toLocalTime());
			}

			if(rs.getTime(6) != null) {
				item.setBreakFinishTime(rs.getTime(6).toLocalTime());
			}

			if(rs.getTime(7) != null) {
				item.setBreakTime(Duration.between(LocalTime.of(0, 0, 0), rs.getTime(7).toLocalTime()));
			}

			if(rs.getTime(8) != null) {
				item.setWorkingHours(Duration.between(LocalTime.of(0, 0, 0), rs.getTime(8).toLocalTime()));
			}

			list.add(item);
		}

		return list;
	}

}
