drop table m_section if exists;

create table m_section (
	section_code varchar(100) not null primary key,
	section_name varchar(100) not null
);

insert into m_section values('a1', 'maguro');

select * from m_section;