drop table work_time if exists;

create table work_time (
	employee_code varchar(100) primary key,
	work_date varchar(100) not null,
	start_time varchar(100),
	finish_time varchar(100),
	break_start_time varchar(100),
	break_finish_time varchar(100),
	break_time varchar(100),
	working_hours varchar(100)
);

insert into work_time values();

select * from work_time;