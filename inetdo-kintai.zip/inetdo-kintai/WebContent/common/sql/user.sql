drop table user if exists;

create table user (
	user_id varchar(100) not null,
	password varchar(100) not null
);

insert into user values('sasakama', 'ikura1739');

select * from user;