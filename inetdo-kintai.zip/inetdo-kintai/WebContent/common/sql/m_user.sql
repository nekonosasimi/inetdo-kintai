drop table m_user if exists;

create table m_user (
	user_id varchar(100) not null,
	password varchar(100) not null
);

insert into m_user values('sasakama', 'ikura1739');

select * from m_user;