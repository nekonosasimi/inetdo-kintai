package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tool.Action;

//トップページ遷移時のアクション
public class SendIndexAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログイン情報の削除
		session.removeAttribute("userId");
		session.removeAttribute("userPassword");

		return "../";
	}

}
