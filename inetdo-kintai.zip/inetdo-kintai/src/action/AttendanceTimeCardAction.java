package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AttendanceEmployeeDAO;
import tool.Action;

public class AttendanceTimeCardAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("employeeCode") != null) {
			//従業員コードの取得
			String employeeCode = (String)session.getAttribute("employeeCode");

			//入力したボタン情報を取得
			String attendance = request.getParameter("attendance");

			//DAOクラスの準備
			AttendanceEmployeeDAO dao = new AttendanceEmployeeDAO();
			boolean flag = false; //処理成否判定用

			try {

				switch(attendance) {
					case "出勤処理":
						flag = dao.setStartTime(employeeCode);
						break;
					case "退勤処理":
						System.out.println("aaaaa");
						flag = dao.setFinishTime(employeeCode);
						break;
					case "休憩開始処理":
						flag = dao.setStartBreakTime(employeeCode);
						break;
					case "休憩終了処理":
						flag = dao.setFinishBreakTime(employeeCode);
						break;
				}

			} catch(Exception e) {
				e.printStackTrace();
			}

			if(flag) {
				session.setAttribute("attendance", attendance);
				return "attendance_completion.jsp";
			} else {
				return "attendance_timecard_error.jsp";
			}

		} else {
			return "../action/attendance_login.jsp";
		}

	}

}
