package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tool.Action;

//従業員情報の削除を行うアクション
public class DeleteEmployeeAction extends Action {

	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		if(session.getAttribute("userId") != null) {


			return "";
		} else {
			return "../action/user_login.jsp";
		}
	}

}
