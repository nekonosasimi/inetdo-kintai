package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tool.Action;

//管理者ログアウト時のアクション
public class LogoutChkAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログイン情報の有無確認
		if(session.getAttribute("userId") != null || session.getAttribute("userPassword") != null) {
			//ログイン情報の削除
			session.removeAttribute("userId");
			session.removeAttribute("userPassword");
			return "user_logout.jsp";
		} else {
			return "user_logout_error.jsp";
		}

	}

}
