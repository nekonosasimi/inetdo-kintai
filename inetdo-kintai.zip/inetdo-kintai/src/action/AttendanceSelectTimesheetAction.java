package action;

import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Employee;
import bean.WorkTime;
import dao.EmployeeDAO;
import dao.WorkTimeDAO;
import tool.Action;

public class AttendanceSelectTimesheetAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("employeeCode") != null) {
			//従業員コードの取得
			String employeeCode = (String)session.getAttribute("employeeCode");
			String thisMonth = request.getParameter("thisMonth"); //選択した月の取得

			//カレンダークラスの準備
			Calendar thisMonthCalneder = Calendar.getInstance();
			thisMonthCalneder.set(Calendar.YEAR, Integer.parseInt(thisMonth.substring(0, 4)));
			thisMonthCalneder.set(Calendar.MONTH, Integer.parseInt(thisMonth.substring(5)));

			//DAOクラスの準備
			WorkTimeDAO wtDao = new WorkTimeDAO();
			EmployeeDAO eDao = new EmployeeDAO();

			try {
				//選択した月の勤務情報を取得
				List<WorkTime> workTimeList = wtDao.selectWorkTimeThisMonthList(employeeCode, thisMonth);
				session.setAttribute("workTimeThisMonthList", workTimeList);

				//ログインユーザの従業員情報を取得
				Employee employee = eDao.selectEmployee(employeeCode);

				//ログインユーザの姓名を取得
				String employeeName = employee.getLastName() + "　" + employee.getFirstName();
				session.setAttribute("employeeName", employeeName);
			} catch(Exception e) {
				e.printStackTrace();
			}

			return "attendance_view_timesheet.jsp";
		} else {
			return "../action/attendance_login.jsp";
		}

	}

}
