package tool;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//Actionクラスのサーブレット
@WebServlet(urlPatterns= {"*.action"})
public class FrontController extends HttpServlet {

	//GETの処理
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//文字コードの設定
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		//書き込み用クラスの取得
		PrintWriter out = response.getWriter();

		//遷移先のurlの取得
		try {
			//指定されたActionクラスの実行
			String path = request.getServletPath().substring(1);
			String name = path.replace(".a", "A").replace('/', '.');
			Action action = (Action)Class.forName(name).newInstance();
			String url = action.execute(request, response);

			//遷移先がTopページかそれ以外で分岐
			if(url.substring(0, 3).equals("../")) {
				response.sendRedirect(url);
			} else {
				request.getRequestDispatcher(url).forward(request, response);
			}

		} catch(Exception e) {
			e.printStackTrace(out);
		}

	}

}
