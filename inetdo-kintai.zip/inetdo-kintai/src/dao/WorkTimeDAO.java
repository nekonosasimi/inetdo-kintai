package dao;

public class WorkTimeDAO extends DAO {

}
