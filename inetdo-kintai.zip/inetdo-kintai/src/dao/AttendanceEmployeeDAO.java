package dao;

public class AttendanceEmployeeDAO extends DAO {

}
