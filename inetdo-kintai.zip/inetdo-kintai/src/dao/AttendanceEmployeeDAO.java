package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

public class AttendanceEmployeeDAO extends DAO {

	//出勤情報を登録
	public boolean setStartTime(String code) throws Exception {
		boolean flag = false; //登録成否判定用

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//現在の日付と時間を取得
		LocalDate nowDate = LocalDate.now();
		LocalTime nowTime = LocalTime.now();

		//SQL文の実行(指定ユーザの本日の出勤情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(nowDate));
		ResultSet rs = st.executeQuery();

		//出勤情報がすでにないかで分岐
		if(!rs.next()) {
			//SQL文の実行(指定ユーザの本日の出勤情報を登録)
			sql = "insert into work_time values(?, ?, ?, null, null, null, null, null)";
			st = con.prepareStatement(sql);
			st.setString(1, code);
			st.setDate(2, Date.valueOf(nowDate));
			st.setTime(3, Time.valueOf(nowTime));
			int line = st.executeUpdate();

			//登録の成否で分岐
			if(line > 0) {
				con.commit(); //コミット
				flag = true;
			} else {
				con.rollback(); //ロールバック
			}

		}

		//オートコミットの設定を戻す
		con.setAutoCommit(true);

		//クローズ処理
		st.close();
		con.close();

		return flag;
	}

	//退勤情報を更新
	public boolean setFinishTime(String code) throws Exception {
		boolean flag = false; //更新成否判定用

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//現在の日付と時間を取得
		LocalDate nowDate = LocalDate.now();
		LocalTime nowTime = LocalTime.now();

		//SQL文の実行(指定ユーザの本日の出勤情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(nowDate));
		ResultSet rs = st.executeQuery();

		//退勤情報がすでに更新されていないかで分岐
		if(rs.next() && rs.getTime(4) == null) {
			LocalTime workStart = rs.getTime(3).toLocalTime(); //出勤時刻の取得
			//LocalTime breakTime = rs.getTime(7).toLocalTime(); //休憩時間の取得 修正予定※※※※※※※※※※※※※※※※※※※※※※

			//SQL文の実行(指定ユーザの本日の退勤時間と勤務時間を更新)
			sql = "update work_time set finish_time = ?, working_hours = ? where employee_code = ? and work_date = ?";
			st = con.prepareStatement(sql);
			st.setTime(1, Time.valueOf(nowTime));
			st.setTime(2, null); //修正する予定※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
			st.setString(3, code);
			st.setDate(4, Date.valueOf(nowDate));
			int line = st.executeUpdate();

			//更新の成否で分岐
			if(line > 0) {
				con.commit(); //コミット
				flag = true;
			} else {
				con.rollback(); //ロールバック
			}

		}

		//オートコミットの設定を戻す
		con.setAutoCommit(true);

		//クローズ処理
		st.close();
		con.close();

		return flag;
	}

	//休憩開始情報を更新
	public boolean setStartBreakTime(String code) throws Exception {
		boolean flag = false; //更新成否判定用

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//現在の日付と時間を取得
		LocalDate nowDate = LocalDate.now();
		LocalTime nowTime = LocalTime.now();

		//SQL文の実行(指定ユーザの本日の出勤情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(nowDate));
		ResultSet rs = st.executeQuery();

		//休憩開始情報がすでに更新されていないかで分岐
		if(rs.next() && rs.getTime(5) == null) {
			//SQL文の実行(指定ユーザの休憩開始時刻を更新)
			sql = "update work_time set break_start_time = ? where employee_code = ? and work_date = ?";
			st = con.prepareStatement(sql);
			st.setTime(1, Time.valueOf(nowTime));
			st.setString(2, code);
			st.setDate(3, Date.valueOf(nowDate));
			int line = st.executeUpdate();

			//更新の成否で分岐
			if(line > 0) {
				con.commit(); //コミット
				flag = true;
			} else {
				con.rollback(); //ロールバック
			}

		}

		//オートコミットの設定を戻す
		con.setAutoCommit(true);

		//クローズ処理
		st.close();
		con.close();

		return flag;
	}

	//休憩開始情報を更新
	public boolean setFinishBreakTime(String code) throws Exception {
		boolean flag = false; //更新成否判定用

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//現在の日付と時間を取得
		LocalDate nowDate = LocalDate.now();
		LocalTime nowTime = LocalTime.now();

		//SQL文の実行(指定ユーザの本日の出勤情報があるか検索)
		String sql = "select * from work_time where employee_code = ? and work_date = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, Date.valueOf(nowDate));
		ResultSet rs = st.executeQuery();

		//休憩開始情報がすでに更新されていないかで分岐
		if(rs.next() && rs.getTime(5) != null && rs.getTime(6) == null) {
			LocalTime breakStart = rs.getTime(5).toLocalTime(); //休憩開始時刻の取得

			//SQL文の実行(指定ユーザの休憩終了時刻と休憩時間を更新)
			sql = "update work_time set break_finish_time = ?, break_time = ? where employee_code = ? and work_date = ?";
			st = con.prepareStatement(sql);
			st.setTime(1, Time.valueOf(nowTime));
			st.setTime(2, null); //修正する予定※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
			st.setString(3, code);
			st.setDate(4, Date.valueOf(nowDate));
			int line = st.executeUpdate();

			//更新の成否で分岐
			if(line > 0) {
				con.commit(); //コミット
				flag = true;
			} else {
				con.rollback(); //ロールバック
			}

		}

		//オートコミットの設定を戻す
		con.setAutoCommit(true);

		//クローズ処理
		st.close();
		con.close();

		return flag;
	}

}
