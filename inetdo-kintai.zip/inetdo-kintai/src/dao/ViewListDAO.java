package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import bean.ViewListDisplay;

//従業員情報表示のDAOクラス
public class ViewListDAO extends DAO {

	//すべての従業員情報の検索
	public List<ViewListDisplay> showAllList() throws Exception {
		List<ViewListDisplay> vldList = new LinkedList<ViewListDisplay>(); //従業員情報格納用リスト

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(すべての従業員情報を検索)
		//m_employeeとm_sectionを連結して部署名も取得
		//ViewListDisplayに合わせて結果を取得
		String sql = "select e.employee_code, concat(e.last_name, e.first_name), "
				+ "concat(e.last_kana_name, e.first_kana_name), e.gender, e.birth_day, s.section_name, e.hire_date "
				+ "from m_employee e left outer join m_section s on e.section_code = s.section_code";
		PreparedStatement st = con.prepareStatement(sql);
		ResultSet rs = st.executeQuery();

		//検索結果をリストに格納
		while(rs.next()) {
			ViewListDisplay vld = new ViewListDisplay();
			vld.setCode(rs.getString(1));
			vld.setName(rs.getString(2));
			vld.setKanaName(rs.getString(3));
			vld.setGender(rs.getInt(4));
			vld.setBirthDay(rs.getDate(5));
			vld.setSectionName(rs.getString(6));
			vld.setHireDate(rs.getDate(7));
			vldList.add(vld);
		}

		//クローズ処理
		st.close();
		con.close();

		return vldList;
	}

}
