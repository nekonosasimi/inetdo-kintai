package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//管理者情報のDAOクラス
public class UserDAO extends DAO {

	//指定したID、パスワードと一致する管理者情報の有無確認
	public boolean loginUser(String id, String password) throws Exception {
		boolean loginChk = false; //ログイン情報認証判定用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定したID、パスワードと一致するデータの取得)
		String sql = "select * from user where user_id = ? and password = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, id);
		st.setString(2, password);
		ResultSet rs = st.executeQuery();

		//検索結果の照合
		if(rs.next()) {

			if(id.equals(rs.getString(1))) {

				if(password.equals(rs.getString(2))) {
					loginChk = true;
				}

			}

		}

		//クローズ処理
		st.close();
		con.close();

		return loginChk;
	}

	//指定したID、パスワードの管理者情報の登録
	public boolean insertUser(String id, String password) throws Exception {
		boolean insertChk = false; //ログイン情報認証判定用

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//SQL文の実行(指定したIDと一致するデータの取得)
		String sql = "select * from user where user_id = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, id);
		ResultSet rs = st.executeQuery();

		//検索結果の有無確認(既にIDが使用されていない場合のみ登録へ移行)
		if(!rs.next()) {
			//SQL文の実行(指定したデータの登録)
			sql = "insert into user values(?, ?)";
			st = con.prepareStatement(sql);
			st.setString(1, id);
			st.setString(2, password);
			int line = st.executeUpdate();

			//データ登録の正否確認
			if(line > 0) {
				insertChk = true;
				con.commit();
			} else {
				con.rollback();
			}

		}

		//オートコミットの設定を戻す
		con.setAutoCommit(true);

		//クローズ処理
		st.close();
		con.close();

		return insertChk;
	}

}
