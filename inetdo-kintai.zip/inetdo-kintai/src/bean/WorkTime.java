package bean;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

//work_timeテーブルのBean(出勤情報)
public class WorkTime implements Serializable {

	private String code; //従業員コード
	private LocalDate workDate; //出勤日
	private LocalTime startTime; //出勤時刻
	private LocalTime finishTime; //退勤時刻
	private LocalTime breakStartTime; //休憩開始時刻
	private LocalTime breakFinishTime; //休憩終了時刻
	private Duration breakTime; //休憩時間
	private Duration workingHours; //勤務時間

	public String getCode() {
		return code;
	}

	public LocalDate getWorkDate() {
		return workDate;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public LocalTime getFinishTime() {
		return finishTime;
	}

	public LocalTime getBreakStartTime() {
		return breakStartTime;
	}

	public LocalTime getBreakFinishTime() {
		return breakFinishTime;
	}

	public Duration getBreakTime() {
		return breakTime;
	}

	public Duration getWorkingHours() {
		return workingHours;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setWorkDate(LocalDate workDate) {
		this.workDate = workDate;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public void setFinishTime(LocalTime finishTime) {
		this.finishTime = finishTime;
	}

	public void setBreakStartTime(LocalTime breakStartTime) {
		this.breakStartTime = breakStartTime;
	}

	public void setBreakFinishTime(LocalTime breakFinishTime) {
		this.breakFinishTime = breakFinishTime;
	}

	public void setBreakTime(Duration breakTime) {
		this.breakTime = breakTime;
	}

	public void setWorkingHours(Duration workingHours) {
		this.workingHours = workingHours;
	}

}
