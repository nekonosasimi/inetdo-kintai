package bean;

import java.io.Serializable;

//sectionテーブルのBean(部署情報)
public class Section implements Serializable {

	private String code; //コード
	private String name; //部署名

	public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setName(String name) {
		this.name = name;
	}

}
