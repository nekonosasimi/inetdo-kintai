package bean;

import java.io.Serializable;

//m_userテーブルのBean(管理者情報)
public class User implements Serializable {

	private String id; //管理者ID
	private String password; //パスワード

	public String getId() {
		return id;
	}

	public String getPassword() {
		return password;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
