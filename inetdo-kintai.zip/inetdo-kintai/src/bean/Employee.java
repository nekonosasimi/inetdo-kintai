package bean;

import java.io.Serializable;

//m_employeeテーブルのBean(従業員情報)
public class Employee implements Serializable {

	//※生年月日、入社日は日付型で取り扱う予定

	String code; //従業員コード
	String lastName; //苗字
	String firstName; //名前
	String lastKanaName; //かな苗字
	String firstKanaName; //かな名前
	int gender; //性別(0=男,1=女)
	String birthDay; //生年月日
	String sectionCode; //部署コード
	String hireDate; //入社日
	String password; //パスワード

	public String getCode() {
		return code;
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastKanaName() {
		return lastKanaName;
	}

	public String getFirstKanaName() {
		return firstKanaName;
	}

	public int getGender() {
		return gender;
	}

	public String getBirthDay() {
		return birthDay;
	}

	public String getSectionCode() {
		return sectionCode;
	}

	public String getHireDate() {
		return hireDate;
	}

	public String getpassword() {
		return password;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastKanaName(String lastKanaName) {
		this.lastKanaName = lastKanaName;
	}

	public void setFirstKanaName(String firstKanaName) {
		this.firstKanaName = firstKanaName;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}

	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}

	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}

	public void setpassword(String password) {
		this.password = password;
	}

}
