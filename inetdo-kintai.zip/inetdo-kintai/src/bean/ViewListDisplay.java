package bean;

import java.io.Serializable;
import java.util.Date;

//表示する従業員情報のBean
public class ViewListDisplay implements Serializable {

	private String code; //従業員コード
	private String name; //氏名
	private String kanaName; //かな氏名
	private String gender; //性別
	private Date birthDay; //誕生日
	private String sectionName; //部署名
	private Date hireDate; //入社日

	public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getKanaName() {
		return kanaName;
	}

	public String getGender() {
		return gender;
	}

	public Date getBirthDay() {
		return birthDay;
	}

	public String getSectionName() {
		return sectionName;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setKanaName(String kanaName) {
		this.kanaName = kanaName;
	}

	public void setGender(int gender) {

		if(gender == 0) {
			this.gender = "男性";
		} else if(gender == 1) {
			this.gender = "女性";
		} else {
			this.gender = "***エラー***";
		}

	}

	public void setBirthDay(Date birthDay) {
		this.birthDay = birthDay;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

}
