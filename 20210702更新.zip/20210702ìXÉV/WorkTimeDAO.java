package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//勤怠管理のDAOクラス
public class WorkTimeDAO extends DAO {

	//本日すでに出勤しているかのチェック
	public boolean selectStartTime(String code) throws Exception {
		boolean workStartChk = false; //出勤確認用

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行指定ユーザの本日の出勤情報の検索(正確には退勤していない情報の有無で検索)
		String sql = "select * from work_time where employee_code = ? and finish_time = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, code);
		st.setDate(2, null);
		ResultSet rs = st.executeQuery();

		//出勤情報があるかの確認
		if(rs.next()) {
			workStartChk = true;
		}

		return workStartChk;
	}

}
