package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.WorkTimeDAO;
import tool.Action;

//出退勤時刻情報を画面に表示させるアクション
public class AttendanceViewTimecardAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//セッションの取得
		HttpSession session = request.getSession();

		//ログインしているかのチェック
		if(session.getAttribute("employeeCode") != null) {
			//従業員コードの取得
			String employeeCode = (String)session.getAttribute("employeeCode");

			//DAOクラスの準備
			WorkTimeDAO dao = new WorkTimeDAO();

			try {
				//本日の出勤情報があるかの確認
				boolean workStartChk = dao.selectStartTime(employeeCode);

				//出勤情報の有無で分岐
				if(workStartChk) {

				} else {

				}

			} catch(Exception e) {
				e.printStackTrace();
			}

			return "attendance_timecard.jsp";
		} else {
			return "../action/attendance_login.jsp";
		}

	}

}
